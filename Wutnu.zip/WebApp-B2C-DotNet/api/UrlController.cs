﻿using System;
using System.Web.Http;
using Infrastructure;
using System.Linq;
using Wutnu.Data;
using System.Collections;
using System.IdentityModel.Claims;
using System.Collections.Generic;

namespace Wutnu.api
{
    /// <summary>
    /// if you decide to do it ajax-y
    /// </summary>
    public class UrlController : ApiController
    {
        private readonly WutCache wutCache;
        private readonly WutNuModels wutModels;

        public UrlController(WutCache cache, WutNuModels models)
        {
            wutCache = cache;
            wutModels = models;
        }
        [Authorize]
        public ShortUrl SaveUrl(ShortUrl url)
        {

            return url;
        }

        public ShortUrl CreateUrl(string realUrl)
        {
            var oUrl = new ShortUrl
            {
                realUrl = realUrl,
                createDate = DateTime.UtcNow,
                createdByIp = ((System.Web.HttpContextWrapper)Request.Properties["MS_HttpContext"]).Request.Se‌​rverVariables["HTTP_HOST"]
            };

            if (User.Identity.IsAuthenticated)
            {
                oUrl.ownerOID = User.Identity.Name;
            }

            oUrl = Utils.AddUrlToDatabase(oUrl, wutModels);

            return oUrl;
        }

        public ShortUrl GetUrl(string short_url)
        {
            short_url = Utils.InternalShortUrl(short_url);
            return Utils.RetrieveUrlFromDatabase(short_url, wutModels);
        }

        [Authorize]
        public IEnumerable<ShortUrl> GetUrls()
        {
            var oid = User.Identity.GetClaim(ClaimTypes.NameIdentifier);
            return wutModels.ShortUrls
                .Where(s => s.ownerOID == oid)
                .OrderBy(s => s.createDate)
                .ToList();
        }
        [Authorize]
        [HttpGet]
        public bool IsUniqueShortLink(string shortLinkCandidate)
        {
            return !(wutModels.ShortUrls.Any(s => s.shortUrl == shortLinkCandidate));
        }
    }
}
