﻿using Infrastructure;
using Microsoft.Restier.EntityFramework;
using System;
using System.Collections.Generic;
using System.IdentityModel.Claims;
using System.Linq;
using System.Web;
using Wutnu.Business;
using Wutnu.Data;

namespace Wutnu
{
    public class WutDataApi : DbApi<WutNuModels>
    {
        private string ownerOID;

        public WutDataApi()
        {
            var ident = HttpContext.Current.User.Identity;
            if (ident.IsAuthenticated)
            {
                ownerOID = ident.GetClaim(ClaimTypes.NameIdentifier);
            }
        }

        protected IQueryable<ShortUrl> OnFilterShortUrl(IQueryable<ShortUrl> entitySet)
        {
            return entitySet.Where(s => s.ownerOID == ownerOID).AsQueryable();
        }
    }
}