namespace Wutnu.Data
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class UrlHistory
    {
        [Key]
        public long HistoryId { get; set; }

        [StringLength(128)]
        public string shortUrl { get; set; }

        public DateTime CallDate { get; set; }

        [StringLength(64)]
        public string HostIp { get; set; }

        [StringLength(128)]
        public string AuthEmail { get; set; }

        public virtual ShortUrl ShortUrl1 { get; set; }
    }
}
