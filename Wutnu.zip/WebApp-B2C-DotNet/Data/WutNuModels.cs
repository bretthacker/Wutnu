namespace Wutnu.Data
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using System.Data.Entity.Migrations;
    public partial class WutNuModels : DbContext
    {
        public WutNuModels()
            : base("name=WutNuModels")
        {
        }

        public virtual DbSet<ErrorLog> ErrorLogs { get; set; }
        public virtual DbSet<ShortUrl> ShortUrls { get; set; }
        public virtual DbSet<UrlHistory> UrlHistories { get; set; }
        public virtual DbSet<UserAssignment> UserAssignments { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ShortUrl>()
                .Property(e => e.createdByIp)
                .IsUnicode(false);

            modelBuilder.Entity<ShortUrl>()
                .HasMany(e => e.UrlHistories)
                .WithOptional(e => e.ShortUrl1)
                .HasForeignKey(e => e.shortUrl);

            modelBuilder.Entity<UrlHistory>()
                .Property(e => e.HostIp)
                .IsUnicode(false);

            modelBuilder.Entity<ShortUrl>()
                .HasMany(e => e.UserAssignments)
                .WithRequired(e => e.ShortUrl1)
                .HasForeignKey(e => e.UserOID);
        }
    }
}
