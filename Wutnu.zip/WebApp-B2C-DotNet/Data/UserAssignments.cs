﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Wutnu.Data
{
    public partial class UserAssignment
    {
        [Key]
        public long UserAssignmentId { get; set; }

        [StringLength(128)]
        [Required]
        public string shortUrl { get; set; }

        [StringLength(128)]
        [Index]
        public string UserOID { get; set; }

        [StringLength(128)]
        [Index]
        public string UserEmail { get; set; }

        public virtual ShortUrl ShortUrl1 { get; set; }
    }
}