namespace Wutnu.Data
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class ShortUrl
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ShortUrl()
        {
            UrlHistories = new HashSet<UrlHistory>();
        }

        [Key]
        [Column("shortUrl")]
        public string shortUrl { get; set; }

        public DateTime createDate { get; set; }

        [StringLength(64)]
        public string createdByIp { get; set; }

        [StringLength(128)]
        public string ownerOID { get; set; }

        public bool isProtected { get; set; }

        public string realUrl { get; set; }

        public string Comments { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<UrlHistory> UrlHistories { get; set; }

        public virtual ICollection<UserAssignment> UserAssignments { get; set; }
    }
}
