namespace Wutnu.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddUserAssignmentEmail : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.UserAssignments", "UserEmail", c => c.String(maxLength: 128));
            CreateIndex("dbo.UserAssignments", "UserEmail");
        }
        
        public override void Down()
        {
            DropIndex("dbo.UserAssignments", new[] { "UserEmail" });
            DropColumn("dbo.UserAssignments", "UserEmail");
        }
    }
}
