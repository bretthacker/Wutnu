﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Wutnu.Infrastructure
{
    public static class CustomClaimTypes
    {
        public static readonly string IdentityProvider = "http://schemas.microsoft.com/identity/claims/identityprovider";
    }
}