﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Wutnu.Infrastructure
{
    public static class Settings
    {
        public static string AppRootPath = HttpContext.Current.Server.MapPath("//");

        public static string EmailDomain { get; set; }
        public static string DomainName { get; set; }

        public static SiteMode SiteMode { get; set; }

        public static DateTime StartTimeUtc { get; set; }

        public const string Redir403 = "~/Home/Unauthorized";

        public const string Redir404 = "~/Home/NotFound";

        public const string Redir500 = "~/Home/Error";

        public static string GetMailTemplate(string templateName)
        {
            var mailPath = Path.Combine(AppRootPath, @"Data\" + templateName);
            return File.ReadAllText(mailPath);
        }
    }
    public enum SiteMode
    {
        Production,
        Maintenance
    }
}
