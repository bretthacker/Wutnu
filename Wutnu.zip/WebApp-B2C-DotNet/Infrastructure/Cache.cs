﻿using System;
using System.Linq;
using StackExchange.Redis;
using Newtonsoft.Json;
using System.Web;

using System.Collections.Concurrent;
using Wutnu.Data;
using Wutnu.Infrastructure;

namespace Wutnu.Data
{
    public class WutCache: IDisposable
    {
        private IDatabase urlcache;
        private ConnectionMultiplexer conn;
        private WutNuModels wutContext;

        public WutCache(WutNuModels model)
        {
            var wb = new HttpContextWrapper(HttpContext.Current);
            wutContext = model;

            conn = Cache.Connection;
            urlcache = conn.GetDatabase(Cache.RedisDBNum);
            if (!conn.IsConnected)
                Logging.WriteMessageToErrorLog("Redis is down", wutContext);
        }

        public ShortUrl GetUrl(string shortKey)
        {
            ShortUrl url = null;
            //check local cache
            var gid = Cache.UrlColl.SingleOrDefault(a => a.Key == shortKey);
            if (gid.Value==null)
            {
                //check Redis cache
                var gidObj = TryGetRedisValue(urlcache, shortKey);
                if (gidObj.HasValue)
                {
                    url = JsonConvert.DeserializeObject<ShortUrl>(gidObj.ToString());
                    //if we're here, it wasn't in the local cache (server restarted)
                    SetLocalUrl(url);
                }
                else
                {
                    //Go to SQL
                    url = wutContext.ShortUrls.SingleOrDefault(g => g.shortUrl == shortKey);
                    //update local and remote cache
                    SetUrl(url);
                }
            }

            return url;
        }
        public void SetLocalUrl(ShortUrl url)
        {
            Cache.UrlColl.AddOrUpdate(url.shortUrl, JsonConvert.SerializeObject(url));
        }
        public bool SetUrl(ShortUrl url)
        {
            try
            {
                if (conn.IsConnected)
                {
                    urlcache.StringSet(url.shortUrl, JsonConvert.SerializeObject(url));
                }

                SetLocalUrl(url);

                return true;
            }
            catch (Exception ex)
            {
                Logging.WriteDebugInfoToErrorLog("Error updating or adding group", ex);
                return false;
            }
        }

        public bool RemoveUrl(ShortUrl url)
        {
            try
            {
                if (conn.IsConnected)
                    urlcache.KeyDelete(url.shortUrl);

                string sOut;
                Cache.UrlColl.TryRemove(url.shortUrl, out sOut);

                return true;
            }
            catch (Exception ex)
            {
                Logging.WriteDebugInfoToErrorLog("Error deleting url", ex);
                return false;
            }

        }
        private RedisValue TryGetRedisValue(IDatabase db, string key)
        {
            RedisValue val = new RedisValue();
            if (conn.IsConnected)
            {
                val = db.StringGet(key);
            }
            return val;
        }

        public void Dispose()
        {
            
        }
    }

    public static class Cache
    {
        public static string RedisConnectionString { get; set; }
        public static ConcurrentDictionary<string, string> UrlColl;
        public static int RedisDBNum { get; set; }

        private static Lazy<ConnectionMultiplexer> lazyConnection = new Lazy<ConnectionMultiplexer>(() =>
        {
            UrlColl = new ConcurrentDictionary<string, string>();

            return ConnectionMultiplexer.Connect(RedisConnectionString);
        });

        public static ConnectionMultiplexer Connection
        {
            get
            {
                return lazyConnection.Value;
            }
        }
    }
    static class ExtensionMethods
    {
        // Either Add or overwrite
        public static void AddOrUpdate<K, V>(this ConcurrentDictionary<K, V> dictionary, K key, V value)
        {
            dictionary.AddOrUpdate(key, value, (oldkey, oldvalue) => value);
        }
    }
}
