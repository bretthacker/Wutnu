﻿using System.Web;
using System.Web.Http;
using Wutnu.Data;

namespace Wutnu.Infrastructure
{
    public class BaseApiController : ApiController
    {
        protected HttpContextBase WebContextBase;
        protected WutNuModels Wutcontext;
        protected WutCache Wutcache;

        public BaseApiController(WutCache cache, WutNuModels models)
        {
            WebContextBase = new HttpContextWrapper(HttpContext.Current);
            Wutcontext = models;
            Wutcache = cache;
        }
    }
}