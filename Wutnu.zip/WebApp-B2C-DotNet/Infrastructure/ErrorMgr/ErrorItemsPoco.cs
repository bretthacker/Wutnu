﻿using System.Collections.Generic;

namespace Wutnu.Infrastructure.ErrorMgr
{
    public class ErrorItemsPoco
    {
        public int RecordCount { get; set; }
        public IEnumerable<ErrorPoco> ErrorItems { get; set; }
    }
}
