﻿using Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using Wutnu.Infrastructure.ErrorMgr;
using Wutnu.Data;

namespace Wutnu.Controllers
{
    public class HomeController : Controller
    {
        private readonly WutCache wutCache;
        private readonly WutNuModels wutModels;

        public HomeController(WutCache cache, WutNuModels models)
        {
            wutCache = cache;
            wutModels = models;
        }

        public ActionResult Index()
        {
            if (Request.Cookies["Error"] != null)
            {
                ViewBag.Error = Request.Cookies["Error"].Value;
            }
            return View();
        }
        /// <summary>
        ///Grab the short URL and look it up for redirection
        ///see MVC routes for definition
        ///(if we wanted to authenticate the user that is trying to expand a link, here's where we'd do it)
        /// </summary>
        /// <param name="shortUrl"></param>
        /// <returns></returns>
        public ActionResult Redir(string id)
        {
            if (id == null)
                return View("Index");

            var res = Utils.RetrieveUrlFromDatabase(id, wutModels);

            if (res == null || (res!=null && res.realUrl== null)) {
                ViewBag.Error="Sorry, that URL wasn't found. Please check your source and try again.";
                return View("Index");
            }

            //todo: log call in a queue for saving the history later (or do it in the retrieve call above)
            return Redirect(res.realUrl);
        }

        /// <summary>
        ///Grab the short URL and look it up for redirection
        ///see MVC routes for definition
        ///(if we wanted to authenticate the user that is trying to expand a link, here's where we'd do it)
        /// </summary>
        /// <param name="shortUrl"></param>
        /// <returns></returns>
        [Authorize]
        public ActionResult RedirAuth(string id)
        {
            if (id == null)
                return View("Index");

            var res = Utils.RetrieveUrlFromDatabase(id, wutModels);

            if (res == null || (res != null && res.realUrl == null))
            {
                ViewBag.Error = "Sorry, that URL wasn't found. Please check your source and try again.";
                return View("Index");
            }

            //todo: log call in a queue for saving the history later (or do it in the retrieve call above)
            return Redirect(res.realUrl);
        }


        public ActionResult Missing()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "When you look at that freaky long URL and go, \"Wut?\".";

            return View();
        }
        public ActionResult Tos()
        {
            return View();
        }

        public ActionResult Privacy()
        {
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "These are not the droids you're looking for.";

            return View();
        }
        public ActionResult IssueInfo()
        {
            return View();
        }
        [HttpPost]
        public ActionResult IssueInfo(string comments)
        {
            if (HttpContext.Session == null) return View();

            var eid = (HttpContext.Session != null && HttpContext.Session["ErrorID"] != null)
                ? HttpContext.Session["ErrorID"].ToString()
                : Request.Form["et"];

            //var emgr = new ErrorMgr(HttpContext.GetOwinContext().Get<WutNuModels>("WutNuModels"), HttpContext);

            var emgr = new ErrorMgr(wutModels, HttpContext);
            try
            {
                var eo = emgr.ReadError(eid);
                if (eo != null)
                {
                    eo.UserComment = comments;
                    emgr.SaveError(eo);
                }
                else
                {
                    //Writing to node WEL
                    emgr.WriteToAppLog("Unable to save user comments to. Comment: " + comments, System.Diagnostics.EventLogEntryType.Error);
                }
            }
            catch (Exception ex)
            {
                //Writing to node WEL
                emgr.WriteToAppLog("Unable to save user comments. \r\nError: " + ex.Message + ". \r\nComment: " + comments, System.Diagnostics.EventLogEntryType.Error);
            }

            return View();
        }
    }
}