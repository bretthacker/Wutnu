﻿using Autofac;
using Autofac.Integration.Mvc;
using Autofac.Integration.WebApi;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Claims;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Wutnu.Business;
using Wutnu.Data;
using Wutnu.Infrastructure;
using Wutnu.Infrastructure.ErrorMgr;

namespace Wutnu
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            //Registration
            ControllerBuilder.Current.DefaultNamespaces.Add("Wutnu.Controllers");
            AreaRegistration.RegisterAllAreas();

            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            AntiForgeryConfig.UniqueClaimTypeIdentifier = ClaimTypes.NameIdentifier;

            //IoC
            var builder = new ContainerBuilder();
            builder.RegisterControllers(typeof(MvcApplication).Assembly);
            builder.RegisterApiControllers(typeof(MvcApplication).Assembly);
            builder.Register(c => new WutNuModels()).AsSelf().InstancePerRequest();
            builder.Register(c => new WutCache(c.Resolve<WutNuModels>())).AsSelf().InstancePerRequest();
            var container = builder.Build();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));
            GlobalConfiguration.Configuration.DependencyResolver = new AutofacWebApiDependencyResolver(container);

            //Settings
            Settings.DomainName = ConfigurationManager.AppSettings["DomainName"];
            Utils.ApplicationName = "Wut?";
            Cache.RedisConnectionString = ConfigurationManager.AppSettings["RedisConnection"];
            Cache.RedisDBNum = Convert.ToInt32(ConfigurationManager.AppSettings["RedisDBNum"]);
            AADGraph.GraphToken = ConfigurationManager.AppSettings["GraphKey"];
            AADGraph.ClientId = ConfigurationManager.AppSettings["ida:ClientIdB2E"];
        }
        /// <summary>
        /// Catchall handler when errors are thrown outside the MVC pipeline
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_Error(object sender, EventArgs e)
        {
            var ex = Server.GetLastError();
            var contextBase = new HttpContextWrapper(Context);
            try
            {
                if ((ex as HttpException).GetHttpCode() == 404) {
                    var s = "~/Home/Redir" + contextBase.Request.FilePath;
                    contextBase.RewritePath(s, false);
                    contextBase.Server.TransferRequest(s);
                }
            }
            catch {}

            if (Context.Items["ErrorID"] != null)
                return;  //this one has already been handled in one of the MVC error filters

            if (ex.InnerException != null)
                ex = ex.InnerException;

            Server.ClearError();
            if (ex == null) return;
            var code = (ex is HttpException) ? (ex as HttpException).GetHttpCode() : 500;

            var bAjax = IsAjaxRequest();
            var sMessage = (bAjax) ? "AJAX call error" : "";
            var eid = Logging.WriteDebugInfoToErrorLog(sMessage, ex);
            Context.Items.Add("ErrorID", eid);  //to keep us from doing this again in the same call

            Response.Clear();

            if (bAjax)
            {
                //this is a json call; tryskip will return our IDs in response.write, 500 will throw in jquery
                Response.TrySkipIisCustomErrors = true;
                Response.StatusCode = 500;
                Response.StatusDescription = String.Format("{0} Application Error", Utils.ApplicationName);
                Response.ContentType = "application/json";
                Response.Write(JsonConvert.SerializeObject(new ErrResponsePoco { DbErrorId = eid }));
                Response.End();
            }
            else
            {
                try
                {
                    SiteUtils.ReturnViaCode(contextBase, code);
                }
                // ReSharper disable once EmptyGeneralCatchClause
                catch (Exception) { }
            }
        }
        /// <summary>
        /// Needed when working with raw Request (HttpRequestBase has this method)
        /// </summary>
        /// <exception cref="ArgumentNullException"></exception>
        /// <returns></returns>
        private bool IsAjaxRequest()
        {
            if (Request == null)
            {
                // ReSharper disable once NotResolvedInText
                throw new ArgumentNullException(paramName: "HttpRequest");
            }

            // ReSharper disable once ConditionIsAlwaysTrueOrFalse
            return (Request["X-Requested-With"] == "XMLHttpRequest") || ((Request.Headers != null) && (Request.Headers["X-Requested-With"] == "XMLHttpRequest"));
        }

    }
}
