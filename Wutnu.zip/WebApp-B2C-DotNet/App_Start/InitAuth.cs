﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Web;
using Microsoft.Ajax.Utilities;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;

namespace Wutnu.App_Start
{
    public static class StartupAuth
    {
        public static ClaimsIdentity InitAuth(CookieResponseSignInContext ctx)
        {
            var ident = ctx.Identity;
            var hctx =
                (HttpContextWrapper)
                    ctx.Request.Environment.Single(e => e.Key == "System.Web.HttpContextBase").Value;

            return InitAuth(ident, hctx, ctx.OwinContext);
        }

        private static ClaimsIdentity InitAuth(ClaimsIdentity ident, HttpContextBase hctx, IOwinContext owinContext)
        {
            try
            {
                var claimEmail = ident.Claims.SingleOrDefault(c => c.Type == ClaimTypes.Email);
                var claimName = ident.Claims.SingleOrDefault(c => c.Type == ClaimTypes.Name);
                var loginString = (claimEmail != null) ? claimEmail.Value : (claimName != null) ? claimName.Value : null;

                //var user = UserBL.GetActiveUserByEmailOrName(efctx, loginString);
                //if (user == null)
                //{
                //    //user not found
                //    ident.AddClaim(new Claim(ClaimTypesLW.LWUnauthorized, "true"));
                //    return ident;
                //}

                ident = TransformClaims(ident);

                return ident;
            }
            catch (Exception ex)
            {
                Debug.Assert(hctx.Session != null, "hctx.Session != null");
                hctx.Session["AuthError"] =
                    "There was an error authenticating. Please contact the system administrator.";
                //Logging.WriteDebugInfoToErrorLog("Error during InitAuth.", ex, hctx, efctx);
                throw;
            }
        }

        private static ClaimsIdentity TransformClaims(ClaimsIdentity ident)
        {
            var issuer = ident.Claims.First().Issuer;

            if (issuer.IndexOf("login.microsoftonline.com")>-1)
            {
                //B2C
                //ident.AddClaim(new Claim(ClaimTypes.Email, user.Email));
                //ident.AddClaim(new Claim(ClaimTypes.Name, ident.Claims.Single(c => c.Type==ClaimTypes.Email).Value));
            }
            else
            {
                //B2B
                //ident.SetClaim(ClaimTypes.Name, user.UserName);
                //ident.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.UserId));
                //ident.AddClaim(new Claim(ClaimTypesLW.InternalOrExternal, user.InternalOrExternal));
            }

            //ident.AddClaim(new Claim(ClaimTypesLW.ResetPasswordOnLogin, user.ResetOnNextLogin.ToString(), typeof(Boolean).ToString()));

            //var enumerable = userRoles as IList<GetLoginUserRole> ?? userRoles.ToList();
            //enumerable.ForEach(r => ident.AddClaim(new Claim(ClaimTypes.Role, r.Name)));

            return ident;
        }
    }
}