﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Azure.ActiveDirectory;
using Microsoft.Azure.ActiveDirectory.GraphClient;
using Microsoft.Azure.ActiveDirectory.GraphClient.Extensions;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace Wutnu.Business
{
    public static class AADGraph
    {
        public static string GraphToken { get; set; }
        public static string ClientId { get; set; }

        const string authString = "https://login.windows.net/hackerdemo.com";
        const string resAzureGraphAPI = "https://graph.windows.net";

        public static string GetGroup(string groupGuid)
        {
            var cli = GetActiveDirectoryClientAsApplication();
            var o = cli.DirectoryObjects.GetByObjectId(groupGuid);
            var g = cli.Groups.GetByObjectId(groupGuid);
            return o.ToString();
        }

        public static ActiveDirectoryClient GetActiveDirectoryClientAsApplication()
        {
            Uri servicePointUri = new Uri("https://graph.windows.net");

            Uri serviceRoot = new Uri(servicePointUri, "hackerdemo.com");

            ActiveDirectoryClient activeDirectoryClient = new ActiveDirectoryClient(serviceRoot, async () => await GetAppTokenAsync());

            return activeDirectoryClient;
            //return null;

        }
        private static async Task<string> GetAppTokenAsync()
        {
            // Instantiate an AuthenticationContext for my directory (see authString above).
            AuthenticationContext authenticationContext = new AuthenticationContext(authString, false);

            // Create a ClientCredential that will be used for authentication.
            // This is where the Client ID and Key/Secret from the Azure Management Portal is used.
            ClientCredential clientCred = new ClientCredential(ClientId, GraphToken);

            // Acquire an access token from Azure AD to access the Azure AD Graph (the resource)
            // using the Client ID and Key/Secret as credentials.
            AuthenticationResult authenticationResult = await authenticationContext.AcquireTokenAsync(resAzureGraphAPI, clientCred);

            // Return the access token.
            return authenticationResult.AccessToken;
        }
    }
}