﻿$(function () {
    //events
    $(".btn-primary.save").on("click", function () {

    });
    $(".btn-warning.delete").on("click", function () {

    });

    $("#isProtected").on("click", function (o) {
        $("#protectedInfo").css("display", (o.currentTarget.checked) ? "block" : "none");
    });

    $("#shortUrl").on("keyup", function () {
        setTimeout(function () {
            var val = $("#shortUrl").val();
            var orgVal = $("#shortUrl").data("orgValue");
            if (val == orgVal) return;

            $("#shortUrlStatus").removeClass("glyphicon-ok").removeClass("glyphicon-remove").addClass("glyphicon-time");
            checkShortLink(val, function (res) {
                if (!res) {
                    SiteUtil.ShowMessage("That code is in use already - please choose another", "Invalid Short Link", SiteUtil.AlertImages.warning, 3000);
                    $("#shortUrl").val(orgVal).focus();
                    $("#shortUrlStatus").removeClass("glyphicon-time").addClass("glyphicon-remove");
                    return;
                }
                $("#shortUrlStatus").removeClass("glyphicon-time").addClass("glyphicon-ok");
                setNewShortUrl(data);
            });
        }, 500);
    });
    $(".listscroll")
        .on("mouseover mouseout", "div", function () {
            $(this).toggleClass("hover");
        });
    $('a[data-toggle="pill"]').on('shown.bs.tab', function (e) {
        switch (e.target.hash) {
            case "#list":
                loadLinks();
                break;
            case "#files":

                break;
            case "#users":

                break;
            case "#reports":

                break;
        }
    });

    var checkShortLink = function (link, callback) {
        SiteUtil.AjaxCall("/api/Url/IsUniqueShortLink", { shortLinkCandidate: link }, function (res) {
            callback(res);
        });
    }
    var getLinks = function (callback) {
        SiteUtil.AjaxCall("/api/Url/GetUrls", { count: 100 }, function (res) {
            callback(res);
        });
    }
    var linkTable;

    function loadLinks() {
        //initial call
        getLinks(function (res) {
            linkTable = $("#urllist").dataTable({
                paging: false,
                data: res,
                oLanguage: {
                    "sEmptyTable": "There are no saved links yet"
                },
                scrollCollapse: false,
                order: [],
                createdRow: function (row, data) {
                    $(row)
                        .on("click", function () { showDetailDialog(data); })
                        .data("data", data);
                },
                columns: [
                    {
                        data: function (o) {
                            if (o.createDate == undefined) return "";
                            return SiteUtil.UtcToLocal(o.createDate);
                        }
                    },
                    { data: "shortUrl" },
                    { data: "realUrl" },
                    { data: "isProtected" },
                    { data: "Comments" }
                ]
            });
        });
    }

    loadLinks();

    //helpers
    var showDetailDialog = function (data) {
        $("#shortUrl").val(data.shortUrl).data("orgValue", data.shortUrl);
        setNewShortUrl(data);
        $("#realUrl").val(data.realUrl);
        $("#isProtected").val(data.isProtected);
        $("#Comments").val(data.Comments);
        $("#EditLinkDialog").data("shortUrl", data.shortUrl).modal('show');
    };
    function setNewShortUrl(data) {
        var lnk = $("#testShortLink");
        var root = lnk.data("root");
        if (data.isProtected) root += "e/";

        lnk.attr("href", root + data.shortUrl);
        lnk.html(root + data.shortUrl);
    }
});
