﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wutnu.Repo
{
    /// <summary>
    /// todo: queue to store caller history for dumping into SQL via web job
    /// </summary>
    public class Queue
    {

    }
}
