﻿using System.Web.Mvc;

namespace Wutnu.Areas.Manage.Controllers
{
    [Authorize]
    public class ErrorLogController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.SiteName = "Wut Admin";
            return View();
        }
    }
}
