﻿using Infrastructure;
using System;
using System.IdentityModel.Claims;
using System.Web.Mvc;
using Wutnu.Data;

namespace Wutnu.Areas.Manage.Controllers
{
    public class GenController : Controller
    {
        private readonly WutCache wutCache;
        private readonly WutNuModels wutModels;

        public GenController(WutCache cache, WutNuModels models)
        {
            wutCache = cache;
            wutModels = models;
        }

        // GET: Gen
        [HttpPost]
        public ActionResult Index(string url)
        {
            //create the record
            var oUrl = new ShortUrl
            {
                realUrl = url,
                createDate = DateTime.UtcNow,
                createdByIp = Request.UserHostAddress
            };
            //tag it if logged in, for posterity or cool reporting later
            if (User.Identity.IsAuthenticated)
            {
                oUrl.ownerOID = User.Identity.GetClaim(ClaimTypes.NameIdentifier);
            }

            //save it
            oUrl = Utils.AddUrlToDatabase(oUrl, wutModels);

            //set it up to display
            ViewBag.ShortUrl = Utils.PublicShortUrl(oUrl.shortUrl);
            ViewBag.NavigateUrl = oUrl.realUrl;

            //go back home
            return View("~/Views/Home/Index.cshtml");
        }
    }
}
